﻿# Capstone Benefit Management System – Backend

This repository contains the backend API for the **Employee Health & Wellness Benefit Management System**, built using **ASP.NET Core 8**, **Oracle Database**, **Entity Framework Core**, **JWT Authentication**, and **XUnit** for testing.

This backend is fully production-ready, scalable, and containerized using Docker.

---

# Features

## Authentication
- User Registration
- Login with JWT Token
- Role-based Authorization (Admin / Member)
- Token expiry and security handling

## Health & Wellness Benefits
### Admin:
- Manage Master Benefits (Create / Update / Deactivate)
- View all users and their enrolled benefits

### Users:
- Browse available benefits
- Enroll into benefits (Health / Wellness)
- Wellness rule enforcement:
  - Only **one active Regular Wellness plan**
  - Emergency Wellness **always allowed**
- Prevent duplicate active enrollments

## Reimbursement System
- Submit monthly reimbursement (upload receipt)
- Upload supported: JPG, PNG, PDF
- File stored in: `wwwroot/Uploads/Receipts`
- Prevent multiple reimbursements per month
- Admin actions:
  - Approve
  - Reject (with reason)
  - Request resubmission
  - Override rule (admin override date)

##  Notification Center
- Users receive notifications for:
  - Plan enrollments
  - Approval/Rejection
  - Override status
  - Resubmission requests
- Mark notifications as read

##  Query System
- Users raise support queries
- Admin can reply
- Show full conversation history

## Fully Tested (XUnit + Moq)
- AuthService tests
- UserBenefitService tests
- ReimbursementService tests
- High-quality test coverage

---

# Architecture

```
Capstone.Api/
 ├── Controllers/
 ├── DTOs/
 │     ├── Auth/
 │     ├── Benefits/
 │     ├── Queries/
 │     ├── Reimbursements/
 │     ├── Notifications/
 ├── Models/
 ├── Repositories/
 │     ├── Interfaces/
 │     └── Implementations/
 ├── Services/
 │     ├── Interfaces/
 │     └── Implementations/
 ├── Middleware/
 ├── wwwroot/
 │     └── Uploads/
 │           └── Receipts/
 ├── Migrations/
 ├── Program.cs
 ├── appsettings.json
 └── Dockerfile
```

---
#  Technology Stack

| Layer | Tech |
|------|------|
| Backend | ASP.NET Core 8 Web API |
| Database | Oracle Free / 21c / 23c |
| ORM | Entity Framework Core |
| Auth | JWT Authentication |
| Logging | Built-in ASP.NET Logging |
| File Storage | Local (wwwroot) |
| Testing | XUnit + Moq |
| Containerization | Docker |

---

#  API Endpoints Overview

### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`

### Benefits
- `GET /api/benefits`
- `POST /api/benefits`
- `PUT /api/benefits/{id}`
- `PUT /api/benefits/{id}/toggle`

### User Benefits
- `GET /api/user-benefits`
- `GET /api/user-benefits/{id}`
- `POST /api/user-benefits` (Enroll)
- `PUT /api/user-benefits/{id}/extend`

### Reimbursements
- `POST /api/reimbursements/submit`
- `DELETE /api/reimbursements/{id}/receipt`
- `GET /api/reimbursements/{id}/receipt`
- `GET /api/reimbursements/my`
- `PUT /api/reimbursements/{id}/approve`
- `PUT /api/reimbursements/{id}/reject`
- `PUT /api/reimbursements/{id}/override`

###  Notifications
- `GET /api/notifications`
- `PUT /api/notifications/{id}/read`

###  Queries
- `GET /api/queries/my`
- `POST /api/queries`
- `PUT /api/queries/{id}/reply`

---

#  Database Structure (Entities)

### ✔ User
### ✔ MasterBenefit
### ✔ UserBenefit
### ✔ Reimbursement
### ✔ Notification
### ✔ Query

---

# File Upload Handling

Uploaded receipts are stored here:

```
wwwroot/Uploads/Receipts
```

Ensure your `Program.cs` includes:

```csharp
app.UseStaticFiles();
```

---

#  Docker Support

## Dockerfile

Placed in `Capstone.Api/`:

```dockerfile
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src

COPY *.sln .
COPY Capstone.Api/*.csproj Capstone.Api/
RUN dotnet restore

COPY Capstone.Api/. Capstone.Api/
WORKDIR /src/Capstone.Api
RUN dotnet publish -c Release -o /app/publish

FROM mcr.microsoft.com/dotnet/aspnet:8.0 AS runtime
WORKDIR /app
COPY --from=build /app/publish .

EXPOSE 8080
ENTRYPOINT ["dotnet", "Capstone.Api.dll"]
```

## Build & Run

```
docker build -t capstone-api .
docker run -p 8080:8080 capstone-api
```

---

# 📦 Running the Application (Without Docker)

### 1. Restore packages
```
dotnet restore
```

### 2. Run migrations
```
dotnet ef database update
```

### 3. Start the API
```
dotnet run
```

Visit Swagger UI:

```
http://localhost:7062/swagger
```

---

# Running Tests

```
dotnet test
```

---

# Environment Variables (appsettings.json)

```json
"ConnectionStrings": {
  "DefaultConnection": "User Id=admin;Password=admin;Data Source=localhost:1521/FREEPDB1"
},
"Jwt": {
  "Key": "THIS_IS_A_SECRET_KEY_123456",
  "Issuer": "CapstoneAPI",
  "Audience": "CapstoneClient",
  "ExpiryHours": "24"
}
```

---
﻿namespace Capstone.Api.Middleware.CustomExceptions
{
    public class LimitExceededException : AppException
    {
        public LimitExceededException()
            : base("The claimed amount exceeds the monthly reimbursement limit.") { }
    }

}

﻿namespace Capstone.Api.Middleware.CustomExceptions
{
    public class WellnessPlanNotActiveException : AppException
    {
        public WellnessPlanNotActiveException()
            : base("This wellness plan is not active or not eligible for reimbursement.") { }
    }
}
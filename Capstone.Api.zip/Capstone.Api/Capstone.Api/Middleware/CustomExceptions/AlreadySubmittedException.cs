﻿namespace Capstone.Api.Middleware.CustomExceptions
{
    public class AlreadySubmittedException : AppException
    {
        public AlreadySubmittedException()
            : base("Reimbursement for this month has already been submitted.") { }
    }
}

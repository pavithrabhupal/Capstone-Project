﻿namespace Capstone.Api.Middleware.CustomExceptions
{
    public class UnauthorizedOperationException : AppException
    {
        public UnauthorizedOperationException()
            : base("You are not allowed to perform this action.") { }
    }

}

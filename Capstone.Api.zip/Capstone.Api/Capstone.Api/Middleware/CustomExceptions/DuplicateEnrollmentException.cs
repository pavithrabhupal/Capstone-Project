﻿namespace Capstone.Api.Middleware.CustomExceptions
{
    public class DuplicateEnrollmentException : AppException
    {
        public DuplicateEnrollmentException()
            : base("User already has an active wellness plan. Only one active wellness plan is allowed.") { }
    }

}

﻿namespace Capstone.Api.Middleware.CustomExceptions
{
    public class ValidationException : AppException
    {
        public ValidationException(string message) : base(message) { }
    }
}

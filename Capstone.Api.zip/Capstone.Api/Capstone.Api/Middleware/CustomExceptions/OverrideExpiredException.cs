﻿namespace Capstone.Api.Middleware.CustomExceptions
{
    public class OverrideExpiredException : AppException
    {
        public OverrideExpiredException()
            : base("Override time window has expired.") { }
    }

}

﻿using System.Net;
using System.Text.Json;
using Capstone.Api.Middleware.CustomExceptions;

namespace Capstone.Api.Middleware
{
    public class ExceptionHandlingMiddleware : IMiddleware
    {
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleException(context, ex);
            }
        }

        private Task HandleException(HttpContext context, Exception ex)
        {
            context.Response.ContentType = "application/json";

            var status = ex switch
            {
                NotFoundException => HttpStatusCode.NotFound,
                ValidationException => HttpStatusCode.BadRequest,
                UnauthorizedOperationException => HttpStatusCode.Forbidden,
                DuplicateEnrollmentException => HttpStatusCode.Conflict,
                LimitExceededException => HttpStatusCode.BadRequest,
                AlreadySubmittedException => HttpStatusCode.Conflict,
                WellnessPlanNotActiveException => HttpStatusCode.BadRequest,
                _ => HttpStatusCode.InternalServerError
            };

            context.Response.StatusCode = (int)status;

            var result = new
            {
                message = ex.Message,
                statusCode = context.Response.StatusCode
            };

            return context.Response.WriteAsync(JsonSerializer.Serialize(result));
        }
    }
}

﻿using Xunit;
using Moq;
using Capstone.Api.Services.Implementations;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Models;
using Capstone.Api.DTOs.Benefits;
using Capstone.Api.Middleware.CustomExceptions;

public class UserBenefitServiceTests
{
    private readonly Mock<IUserBenefitRepository> _userBenefitRepo;
    private readonly Mock<IMasterBenefitRepository> _masterBenefitRepo;
    private readonly Mock<IUserRepository> _userRepo;
    private readonly UserBenefitService _service;

    public UserBenefitServiceTests()
    {
        _userBenefitRepo = new Mock<IUserBenefitRepository>();
        _masterBenefitRepo = new Mock<IMasterBenefitRepository>();
        _userRepo = new Mock<IUserRepository>();

        _service = new UserBenefitService(
            _userBenefitRepo.Object,
            _masterBenefitRepo.Object,
            _userRepo.Object
        );
    }

    // -------------------------------------------------------------------------
    // 1. Admin / user gets benefits by ID
    // -------------------------------------------------------------------------
    [Fact]
    public async Task GetByUserIdAsync_ShouldReturnMappedDtos()
    {
        _userBenefitRepo.Setup(r => r.GetByUserIdAsync(3))
            .ReturnsAsync(new List<UserBenefit>
            {
                new UserBenefit
                {
                    UserBenefitId = 10,
                    UserId = 3,
                    MasterBenefitId = 5,
                    MasterBenefit = new MasterBenefit
                    {
                        BenefitName = "Dental Basic",
                        Category = "Health",
                        SubCategory = "Regular",
                        Provider = "Apollo",
                        DefaultCopay = 300
                    },
                    EffectiveDate = DateTime.UtcNow.AddDays(-5),
                    ExpiryDate = DateTime.UtcNow.AddMonths(6),
                    Status = "Active",
                    AdminExtended = 0
                }
            });

        var result = await _service.GetByUserIdAsync(3);

        Assert.Single(result);
        Assert.Equal("Dental Basic", result.First().BenefitName);
        Assert.Equal("Health", result.First().Category);
        Assert.Equal(5, result.First().MasterBenefitId);
    }

    // -------------------------------------------------------------------------
    // 2. Enroll: Throws if user not found
    // -------------------------------------------------------------------------
    [Fact]
    public async Task EnrollAsync_ShouldThrow_WhenUserNotFound()
    {
        _userRepo.Setup(r => r.GetByIdAsync(1))
                 .ReturnsAsync((User)null);

        var dto = new AddUserBenefitDto
        {
            MasterBenefitId = 10,
            EffectiveDate = DateTime.UtcNow,
            ExpiryDate = DateTime.UtcNow.AddMonths(1)
        };

        await Assert.ThrowsAsync<NotFoundException>(() =>
            _service.EnrollAsync(1, dto)
        );
    }

    // -------------------------------------------------------------------------
    // 3. Enroll: Throws if benefit not found
    // -------------------------------------------------------------------------
    [Fact]
    public async Task EnrollAsync_ShouldThrow_WhenBenefitNotFound()
    {
        _userRepo.Setup(r => r.GetByIdAsync(1))
                 .ReturnsAsync(new User { UserId = 1 });

        _masterBenefitRepo.Setup(r => r.GetByIdAsync(10))
                          .ReturnsAsync((MasterBenefit)null);

        var dto = new AddUserBenefitDto { MasterBenefitId = 10 };

        await Assert.ThrowsAsync<NotFoundException>(() =>
            _service.EnrollAsync(1, dto)
        );
    }

    // -------------------------------------------------------------------------
    // 4. Enroll: Prevent duplicate active plan
    // -------------------------------------------------------------------------
    [Fact]
    public async Task EnrollAsync_ShouldThrow_WhenSameActivePlanExists()
    {
        _userRepo.Setup(r => r.GetByIdAsync(1))
                 .ReturnsAsync(new User { UserId = 1 });

        _masterBenefitRepo.Setup(r => r.GetByIdAsync(10))
                          .ReturnsAsync(new MasterBenefit
                          {
                              MasterBenefitId = 10,
                              BenefitName = "Vision",
                              Category = "Health",
                              Status = "Active"
                          });

        _userBenefitRepo.Setup(r => r.GetByUserIdAsync(1))
            .ReturnsAsync(new List<UserBenefit>
            {
                new UserBenefit
                {
                    MasterBenefitId = 10,
                    Status = "Active",
                    MasterBenefit = new MasterBenefit { Category = "Health" }
                }
            });

        var dto = new AddUserBenefitDto { MasterBenefitId = 10 };

        await Assert.ThrowsAsync<ValidationException>(() =>
            _service.EnrollAsync(1, dto)
        );
    }

    // -------------------------------------------------------------------------
    // 5. Enroll: Prevent second Regular Wellness plan
    // -------------------------------------------------------------------------
    [Fact]
    public async Task EnrollAsync_ShouldThrow_WhenSecondRegularWellnessPlan()
    {
        _userRepo.Setup(r => r.GetByIdAsync(1))
                 .ReturnsAsync(new User { UserId = 1 });

        _masterBenefitRepo.Setup(r => r.GetByIdAsync(10))
                          .ReturnsAsync(new MasterBenefit
                          {
                              MasterBenefitId = 10,
                              BenefitName = "Gym Plan",
                              Category = "Wellness",
                              SubCategory = "Regular",
                              Status = "Active"
                          });

        _userBenefitRepo.Setup(r => r.GetByUserIdAsync(1))
            .ReturnsAsync(new List<UserBenefit>
            {
                new UserBenefit
                {
                    MasterBenefitId = 5,
                    Status = "Active",
                    MasterBenefit = new MasterBenefit
                    {
                        Category = "Wellness",
                        SubCategory = "Regular"
                    }
                }
            });

        var dto = new AddUserBenefitDto { MasterBenefitId = 10 };

        await Assert.ThrowsAsync<DuplicateEnrollmentException>(() =>
            _service.EnrollAsync(1, dto)
        );
    }

    // -------------------------------------------------------------------------
    // 6. Enroll: Successful enrollment
    // -------------------------------------------------------------------------
    [Fact]
    public async Task EnrollAsync_ShouldReturnDto_WhenSuccessful()
    {
        _userRepo.Setup(r => r.GetByIdAsync(1))
                 .ReturnsAsync(new User { UserId = 1 });

        _masterBenefitRepo.Setup(r => r.GetByIdAsync(10))
                          .ReturnsAsync(new MasterBenefit
                          {
                              MasterBenefitId = 10,
                              BenefitName = "Dental Care",
                              Category = "Health",
                              SubCategory = "Regular",
                              Status = "Active"
                          });

        _userBenefitRepo.Setup(r => r.GetByUserIdAsync(1))
            .ReturnsAsync(new List<UserBenefit>()); // No active plans

        _userBenefitRepo.Setup(r => r.AddAsync(It.IsAny<UserBenefit>()))
                        .Returns(Task.CompletedTask);

        var dto = new AddUserBenefitDto
        {
            MasterBenefitId = 10,
            EffectiveDate = DateTime.UtcNow,
            ExpiryDate = DateTime.UtcNow.AddMonths(6)
        };

        var result = await _service.EnrollAsync(1, dto);

        Assert.NotNull(result);
        Assert.Equal("Dental Care", result.BenefitName);
        Assert.Equal(10, result.MasterBenefitId);
    }
}

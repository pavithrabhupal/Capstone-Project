﻿using Capstone.Api.DTOs.Reimbursements;
using Capstone.Api.Middleware.CustomExceptions;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Services.Implementations;
using Microsoft.AspNetCore.Hosting;
using Moq;
using Xunit;

public class ReimbursementServiceTests
{
    private readonly Mock<IReimbursementRepository> _repo;
    private readonly Mock<IUserBenefitRepository> _userBenefitRepo;
    private readonly Mock<IUserRepository> _userRepo;
    private readonly Mock<INotificationRepository> _notificationRepo;
    private readonly Mock<IWebHostEnvironment> _env;

    private readonly ReimbursementService _service;

    public ReimbursementServiceTests()
    {
        _repo = new Mock<IReimbursementRepository>();
        _userBenefitRepo = new Mock<IUserBenefitRepository>();
        _userRepo = new Mock<IUserRepository>();
        _notificationRepo = new Mock<INotificationRepository>();
        _env = new Mock<IWebHostEnvironment>();

        _env.Setup(e => e.ContentRootPath).Returns("C:/fakepath");

        _service = new ReimbursementService(
            _repo.Object,
            _userBenefitRepo.Object,
            _userRepo.Object,
            _notificationRepo.Object,
            _env.Object
        );
    }

    [Fact]
    public async Task SubmitAsync_ShouldThrow_WhenUserDoesNotExist()
    {
        _userRepo.Setup(x => x.GetByIdAsync(1)).ReturnsAsync((User)null);

        var dto = new SubmitReimbursementDto
        {
            UserBenefitId = 10,
            Amount = 500,
            DateOfActivity = DateTime.UtcNow
        };

        await Assert.ThrowsAsync<NotFoundException>(() =>
            _service.SubmitAsync(1, dto)
        );
    }

    [Fact]
    public async Task SubmitAsync_ShouldThrow_WhenBenefitNotFound()
    {
        _userRepo.Setup(x => x.GetByIdAsync(1)).ReturnsAsync(new User { UserId = 1 });

        _userBenefitRepo.Setup(x => x.GetByIdAsync(10))
            .ReturnsAsync((UserBenefit)null);

        var dto = new SubmitReimbursementDto
        {
            UserBenefitId = 10,
            Amount = 500,
            DateOfActivity = DateTime.UtcNow
        };

        await Assert.ThrowsAsync<NotFoundException>(() =>
            _service.SubmitAsync(1, dto)
        );
    }

    [Fact]
    public async Task SubmitAsync_ShouldSucceed_WhenValid()
    {
        // Arrange mock user
        _userRepo.Setup(x => x.GetByIdAsync(1)).ReturnsAsync(new User { UserId = 1 });

        // Mock benefit
        _userBenefitRepo.Setup(x => x.GetByIdAsync(10)).ReturnsAsync(new UserBenefit
        {
            UserBenefitId = 10,
            UserId = 1,
            EffectiveDate = DateTime.UtcNow.AddDays(-5),
            ExpiryDate = DateTime.UtcNow.AddDays(5),
            MasterBenefit = new MasterBenefit
            {
                MonthlyLimit = 1000,
                Category = "Wellness"
            }
        });

        // No previous reimbursements
        _repo.Setup(x => x.ExistsForMonthAsync(1, 10, It.IsAny<string>()))
            .ReturnsAsync(false);

        // Act
        var dto = new SubmitReimbursementDto
        {
            UserBenefitId = 10,
            Amount = 300,
            DateOfActivity = DateTime.UtcNow
        };

        var result = await _service.SubmitAsync(1, dto);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(300, result.Amount);
        Assert.Equal("Submitted", result.Status);
        _repo.Verify(x => x.AddAsync(It.IsAny<Reimbursement>()), Times.Once);
    }
}

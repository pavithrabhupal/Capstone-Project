﻿using Xunit;
using Moq;
using Capstone.Api.Services.Implementations;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Helpers;
using Microsoft.Extensions.Configuration;
using Capstone.Api.DTOs.Auth;
using Capstone.Api.Models;

public class AuthServiceTests
{
    private readonly Mock<IUserRepository> _userRepo;
    private readonly Mock<IPasswordHasher> _hasher;
    private readonly Mock<IConfiguration> _config;
    private readonly AuthService _service;

    public AuthServiceTests()
    {
        _userRepo = new Mock<IUserRepository>();
        _hasher = new Mock<IPasswordHasher>();
        _config = new Mock<IConfiguration>();

        // Mock the JWT configuration so token generation doesn't fail
        _config.Setup(c => c["Jwt:Key"]).Returns("THIS_IS_A_TEST_SECRET_KEY_1234567890");
        _config.Setup(c => c["Jwt:Issuer"]).Returns("TestIssuer");
        _config.Setup(c => c["Jwt:Audience"]).Returns("TestAudience");
        _config.Setup(c => c["Jwt:ExpiryHours"]).Returns("1");

        _service = new AuthService(
            _userRepo.Object,
            _hasher.Object,
            _config.Object
        );
    }

    [Fact]
    public async Task Login_ShouldReturnNull_WhenUserNotFound()
    {
        // Arrange
        _userRepo.Setup(x => x.GetByEmailAsync("test@gmail.com"))
            .ReturnsAsync((User)null);

        // Act
        var result = await _service.LoginAsync(new LoginDto
        {
            Email = "test@gmail.com",
            Password = "pass"
        });

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public async Task Login_ShouldReturnNull_WhenPasswordIncorrect()
    {
        _userRepo.Setup(x => x.GetByEmailAsync("test@gmail.com"))
            .ReturnsAsync(new User
            {
                UserId = 1,
                Email = "test@gmail.com",
                PasswordHash = "hashedPassword",
                Role = "Member"
            });

        _hasher.Setup(h => h.Verify("wrongpass", "hashedPassword"))
            .Returns(false);

        var result = await _service.LoginAsync(new LoginDto
        {
            Email = "test@gmail.com",
            Password = "wrongpass"
        });

        Assert.Null(result);
    }

    [Fact]
    public async Task Login_ShouldReturnToken_WhenValidCredentials()
    {
        _userRepo.Setup(x => x.GetByEmailAsync("test@gmail.com"))
            .ReturnsAsync(new User
            {
                UserId = 1,
                Email = "test@gmail.com",
                PasswordHash = "hashedPassword",
                Role = "Member"
            });

        _hasher.Setup(h => h.Verify("correct", "hashedPassword"))
            .Returns(true);

        var result = await _service.LoginAsync(new LoginDto
        {
            Email = "test@gmail.com",
            Password = "correct"
        });

        Assert.NotNull(result);
        Assert.NotNull(result.Token);
        Assert.Equal(1, result.UserId);
        Assert.Equal("Member", result.Role);
    }


}

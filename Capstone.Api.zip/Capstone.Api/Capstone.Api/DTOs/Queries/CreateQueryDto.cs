﻿namespace Capstone.Api.DTOs.Queries
{
    public class CreateQueryDto
    {
        public string Subject { get; set; }
        public string Message { get; set; }
    }
}

﻿namespace Capstone.Api.DTOs.Queries
{
    public class ReplyQueryDto
    {
        public string Reply { get; set; }
    }
}

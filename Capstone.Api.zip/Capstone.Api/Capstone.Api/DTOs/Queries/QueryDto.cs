﻿namespace Capstone.Api.DTOs.Queries
{
    public class QueryDto
    {
        public long QueryId { get; set; }
        public long UserId { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
        public string? Reply { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? RepliedAt { get; set; }
    }
}

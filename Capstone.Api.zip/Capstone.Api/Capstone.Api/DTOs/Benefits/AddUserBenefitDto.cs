﻿namespace Capstone.Api.DTOs.Benefits
{
    public class AddUserBenefitDto
    {
        public long MasterBenefitId { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ExpiryDate { get; set; }
    }
}

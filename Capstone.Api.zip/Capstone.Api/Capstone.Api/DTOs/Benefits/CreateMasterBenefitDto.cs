﻿namespace Capstone.Api.DTOs.Benefits
{
    public class CreateMasterBenefitDto
    {
        public string BenefitName { get; set; }
        public string Category { get; set; } // Health / Wellness
        public string SubCategory { get; set; } = "Regular";
        public string? Description { get; set; }
        public string? Provider { get; set; }
        public decimal? DefaultCopay { get; set; }
        public decimal? MonthlyLimit { get; set; }
    }
}

﻿namespace Capstone.Api.DTOs.Benefits
{
    public class MasterBenefitDto
    {
        public long MasterBenefitId { get; set; }
        public string BenefitName { get; set; }
        public string Category { get; set; } // Health or Wellness
        public string SubCategory { get; set; } // Regular or Emergency
        public string? Description { get; set; }
        public string? Provider { get; set; }
        public decimal? DefaultCopay { get; set; }
        public decimal? MonthlyLimit { get; set; }
        public string Status { get; set; }
    }
}

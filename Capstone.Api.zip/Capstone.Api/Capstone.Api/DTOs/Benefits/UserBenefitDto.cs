﻿namespace Capstone.Api.DTOs.Benefits
{
    public class UserBenefitDto
    {
        public long UserBenefitId { get; set; }
        public long UserId { get; set; }
        public long MasterBenefitId { get; set; }

        public string BenefitName { get; set; }
        public string Category { get; set; }  // Health / Wellness
        public string SubCategory { get; set; } // Regular / Emergency

        public DateTime EffectiveDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Status { get; set; }

        public string? Provider { get; set; }
        public decimal? DefaultCopay { get; set; }
        public decimal? MonthlyLimit { get; set; }

        public int AdminExtended {  get; set; }
    }
}

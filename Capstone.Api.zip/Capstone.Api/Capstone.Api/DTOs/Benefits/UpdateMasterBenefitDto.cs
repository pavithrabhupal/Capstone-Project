﻿namespace Capstone.Api.DTOs.Benefits
{
    public class UpdateMasterBenefitDto
    {
        public string BenefitName { get; set; }
        public string SubCategory { get; set; }
        public string? Description { get; set; }
        public string? Provider { get; set; }
        public decimal? DefaultCopay { get; set; }
        public decimal? MonthlyLimit { get; set; }
    }
}

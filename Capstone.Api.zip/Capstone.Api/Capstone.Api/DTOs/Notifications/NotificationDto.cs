﻿namespace Capstone.Api.DTOs.Notifications
{
    public class NotificationDto
    {
        public long NotificationId { get; set; }
        public long UserId { get; set; }
        public string Message { get; set; }
        public string Type { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}

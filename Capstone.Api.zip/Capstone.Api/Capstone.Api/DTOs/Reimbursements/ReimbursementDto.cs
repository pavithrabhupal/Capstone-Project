﻿namespace Capstone.Api.DTOs.Reimbursements
{
    public class ReimbursementDto
    {
        public long ReimbursementId { get; set; }
        public long UserBenefitId { get; set; }
        public string MonthYear { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }
        public string ReceiptPath { get; set; }
    }
}

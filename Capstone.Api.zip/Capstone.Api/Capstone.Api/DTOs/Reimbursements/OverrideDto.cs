﻿namespace Capstone.Api.DTOs.Reimbursements
{
    public class OverrideDto
    {
        public string Reason { get; set; }
        public DateTime ExpiryDate {  get; set; }
    }
}

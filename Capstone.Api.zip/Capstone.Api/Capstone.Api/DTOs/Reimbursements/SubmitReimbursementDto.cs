﻿namespace Capstone.Api.DTOs.Reimbursements
{
    public class SubmitReimbursementDto
    {
        public long UserBenefitId { get; set; }
        public decimal Amount { get; set; }
        public DateTime DateOfActivity { get; set; }
        //public string ReceiptPath { get; set; }
        public IFormFile? ReceiptFile { get; set; }
    }
}

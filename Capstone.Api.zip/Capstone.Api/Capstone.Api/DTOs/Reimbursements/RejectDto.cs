﻿namespace Capstone.Api.DTOs.Reimbursements
{
    public class RejectDto
    {
        public string Reason { get; set; }
    }
}

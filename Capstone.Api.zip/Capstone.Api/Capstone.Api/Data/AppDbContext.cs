﻿using Capstone.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace Capstone.Api.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users => Set<User>();
        public DbSet<MasterBenefit> MasterBenefits => Set<MasterBenefit>();
        public DbSet<UserBenefit> UserBenefits => Set<UserBenefit>();
        public DbSet<Reimbursement> Reimbursements => Set<Reimbursement>();
        public DbSet<Query> Queries => Set<Query>();
        public DbSet<Notification> Notifications => Set<Notification>();


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<MasterBenefit>()
                .Property(m => m.DefaultCopay)
                .HasPrecision(10, 2);

            modelBuilder.Entity<MasterBenefit>()
                .Property(m => m.MonthlyLimit)
                .HasPrecision(10, 2);

            modelBuilder.Entity<Reimbursement>()
                .Property(r => r.Amount)
                .HasPrecision(10, 2);

            //  RELATIONSHIPS

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            modelBuilder.Entity<UserBenefit>()
                .HasOne(ub => ub.User)
                .WithMany(u => u.UserBenefits)
                .HasForeignKey(ub => ub.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<UserBenefit>()
                .HasOne(ub => ub.MasterBenefit)
                .WithMany(mb => mb.UserBenefits)
                .HasForeignKey(ub => ub.MasterBenefitId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Reimbursement>()
                .HasOne(r => r.User)
                .WithMany(u => u.Reimbursements)
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Reimbursement>()
                .HasOne(r => r.UserBenefit)
                .WithMany(ub => ub.Reimbursements)
                .HasForeignKey(r => r.UserBenefitId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Query>()
                .HasOne(q => q.User)
                .WithMany(u => u.Queries)
                .HasForeignKey(q => q.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Notification>()
                .HasOne(n => n.User)
                .WithMany(u => u.Notifications)
                .HasForeignKey(n => n.UserId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}

﻿using Capstone.Api.Helpers;
using Capstone.Api.Models;

namespace Capstone.Api.Data
{
    public class DbInitializer
    {
        private readonly AppDbContext _context;
        private readonly IPasswordHasher _passwordHasher;

        public DbInitializer(AppDbContext context, IPasswordHasher passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher;
        }

        public async Task InitializeAsync()
        {
            // Seed Admin
            if (_context.Users.Count(u => u.Role == "Admin") == 0)
            {
                var admin = new User
                {
                    FullName = "System Admin",
                    Email = "admin@company.com",
                    PasswordHash = _passwordHasher.Hash("Admin@123"),
                    Role = "Admin",
                    CreatedAt = DateTime.UtcNow
                };

                _context.Users.Add(admin);
            }

            // Seed Members
            if (_context.Users.Count(u => u.Role == "Member") == 0)
            {
                _context.Users.AddRange(
                    new User
                    {
                        FullName = "John Doe",
                        Email = "john@gmail.com",
                        PasswordHash = _passwordHasher.Hash("User@123"),
                        Role = "Member",
                        CreatedAt = DateTime.UtcNow
                    },
                    new User
                    {
                        FullName = "Priya Sharma",
                        Email = "priya@gmail.com",
                        PasswordHash = _passwordHasher.Hash("User@123"),
                        Role = "Member",
                        CreatedAt = DateTime.UtcNow
                    }
                );
            }

            await _context.SaveChangesAsync();

            // Reload users
            var john = _context.Users.FirstOrDefault(u => u.Email == "john@gmail.com");
            var priya = _context.Users.FirstOrDefault(u => u.Email == "priya@gmail.com");

            // Seed Master Benefits
            if (_context.MasterBenefits.Count() == 0)
            {
                _context.MasterBenefits.AddRange(
                    new MasterBenefit
                    {
                        BenefitName = "Dental Basic",
                        Category = "Health",
                        SubCategory = "Regular",
                        Provider = "Apollo",
                        DefaultCopay = 500,
                        Status = "Active"
                    },
                    new MasterBenefit
                    {
                        BenefitName = "Vision Care",
                        Category = "Health",
                        SubCategory = "Regular",
                        Provider = "Fortis",
                        DefaultCopay = 300,
                        Status = "Active"
                    },
                    new MasterBenefit
                    {
                        BenefitName = "Gym Membership",
                        Category = "Wellness",
                        SubCategory = "Regular",
                        MonthlyLimit = 800,
                        Status = "Active"
                    },
                    new MasterBenefit
                    {
                        BenefitName = "Emergency Therapy",
                        Category = "Wellness",
                        SubCategory = "Emergency",
                        MonthlyLimit = 500,
                        Status = "Active"
                    }
                );
            }

            await _context.SaveChangesAsync();

            // Reload benefits
            var dental = _context.MasterBenefits.FirstOrDefault(m => m.BenefitName == "Dental Basic");
            var vision = _context.MasterBenefits.FirstOrDefault(m => m.BenefitName == "Vision Care");
            var gym = _context.MasterBenefits.FirstOrDefault(m => m.BenefitName == "Gym Membership");

            // Seed UserBenefits
            if (_context.UserBenefits.Count() == 0)
            {
                if (john != null && gym != null) 
                {
                    _context.UserBenefits.Add(new UserBenefit
                    {
                        UserId = john.UserId,
                        MasterBenefitId = gym.MasterBenefitId,
                        EffectiveDate = new DateTime(2025, 1, 1),
                        ExpiryDate = new DateTime(2025, 6, 30),
                        Status = "Active",
                        AdminExtended = 0
                    });
                }

                if (priya != null && dental != null)
                {
                    _context.UserBenefits.Add(new UserBenefit
                    {
                        UserId = priya.UserId,
                        MasterBenefitId = dental.MasterBenefitId,
                        EffectiveDate = DateTime.UtcNow.Date,
                        ExpiryDate = DateTime.UtcNow.Date.AddYears(1),
                        Status = "Active",
                        AdminExtended = 0
                    });
                }

                if (priya != null && vision != null)
                {
                    _context.UserBenefits.Add(new UserBenefit
                    {
                        UserId = priya.UserId,
                        MasterBenefitId = vision.MasterBenefitId,
                        EffectiveDate = DateTime.UtcNow.Date,
                        ExpiryDate = DateTime.UtcNow.Date.AddYears(1),
                        Status = "Active",
                        AdminExtended = 0
                    });
                }
            }

            await _context.SaveChangesAsync();
        }
    }
}

﻿using Capstone.Api.Data;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Capstone.Api.Repositories.Implementations
{
    public class QueryRepository : IQueryRepository
    {
        private readonly AppDbContext _context;
        public QueryRepository(AppDbContext context) => _context = context;

        public async Task<IEnumerable<Query>> GetByUserAsync(long userId) =>
            await _context.Queries.Where(q => q.UserId == userId).ToListAsync();

        public async Task<IEnumerable<Query>> GetAllAsync() =>
            await _context.Queries.ToListAsync();

        public async Task<Query?> GetByIdAsync(long id) =>
            await _context.Queries.FindAsync(id);

        public async Task AddAsync(Query query)
        {
            await _context.Queries.AddAsync(query);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Query query)
        {
            _context.Queries.Update(query);
            await _context.SaveChangesAsync();
        }
    }
}

﻿using Capstone.Api.Data;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Capstone.Api.Repositories.Implementations
{
    public class MasterBenefitRepository : IMasterBenefitRepository
    {
        private readonly AppDbContext _context;
        public MasterBenefitRepository(AppDbContext context) => _context = context;

        public async Task<IEnumerable<MasterBenefit>> GetAllAsync() =>
            await _context.MasterBenefits.ToListAsync();

        public async Task<MasterBenefit?> GetByIdAsync(long id) =>
            await _context.MasterBenefits.FindAsync(id);

        public async Task AddAsync(MasterBenefit benefit)
        {
            await _context.MasterBenefits.AddAsync(benefit);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(MasterBenefit benefit)
        {
            _context.MasterBenefits.Update(benefit);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> ExistsAsync(long id) =>
            await _context.MasterBenefits.AnyAsync(m => m.MasterBenefitId == id);
    }
}

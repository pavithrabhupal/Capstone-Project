﻿using Capstone.Api.Data;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Capstone.Api.Repositories.Implementations
{
    public class UserBenefitRepository : IUserBenefitRepository
    {
        private readonly AppDbContext _context;

        public UserBenefitRepository(AppDbContext context) => _context = context;

        public async Task<IEnumerable<UserBenefit>> GetByUserIdAsync(long userId) =>
            await _context.UserBenefits
                .Include(ub => ub.MasterBenefit)
                .Where(ub => ub.UserId == userId)
                .ToListAsync();

        public async Task<UserBenefit?> GetByIdAsync(long id) =>
            await _context.UserBenefits
                .Include(ub => ub.MasterBenefit)
                .FirstOrDefaultAsync(ub => ub.UserBenefitId == id);

        public async Task AddAsync(UserBenefit userBenefit)
        {
            await _context.UserBenefits.AddAsync(userBenefit);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> HasActiveWellnessPlanAsync(long userId) =>
            await _context.UserBenefits
                .Include(ub => ub.MasterBenefit)
                .AnyAsync(ub =>
                    ub.UserId == userId &&
                    ub.MasterBenefit.Category == "Wellness" &&
                    ub.Status == "Active"
                );

        public async Task<bool> UserBenefitExistsAsync(long userId, long masterBenefitId) =>
            await _context.UserBenefits.AnyAsync(ub =>
                ub.UserId == userId && ub.MasterBenefitId == masterBenefitId);

    }
}

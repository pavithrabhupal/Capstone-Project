﻿using Capstone.Api.Data;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Capstone.Api.Repositories.Implementations
{
    public class ReimbursementRepository : IReimbursementRepository
    {
        private readonly AppDbContext _context;

        public ReimbursementRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task AddAsync(Reimbursement r)
        {
            _context.Reimbursements.Add(r);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Reimbursement r)
        {
            _context.Reimbursements.Update(r);
            await _context.SaveChangesAsync();
        }

        public async Task<Reimbursement?> GetByIdAsync(long id)
        {
            return await _context.Reimbursements
                .Include(r => r.UserBenefit)
                .ThenInclude(ub => ub.MasterBenefit)
                .FirstOrDefaultAsync(r => r.ReimbursementId == id);
        }

        public async Task<bool> ExistsForMonthAsync(long userId, long userBenefitId, string monthYear)
        {
            return await _context.Reimbursements.AnyAsync(r =>
                r.UserId == userId &&
                r.UserBenefitId == userBenefitId &&
                r.MonthYear == monthYear &&
                r.Status != "Rejected");
        }

        // ⭐ FIXED — Get reimbursements for user
        public async Task<IEnumerable<Reimbursement>> GetByUserAsync(long userId)
        {
            return await _context.Reimbursements
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.SubmittedAt)
                .ToListAsync();
        }

        // ⭐ FIXED — Get all reimbursements
        public async Task<IEnumerable<Reimbursement>> GetAllAsync()
        {
            return await _context.Reimbursements
                .OrderByDescending(r => r.SubmittedAt)
                .ToListAsync();
        }

        // Pending ones for Admin
        public async Task<IEnumerable<Reimbursement>> GetPendingAsync()
        {
            return await _context.Reimbursements
                .Where(r => r.Status == "Submitted" || r.Status == "NeedsResubmission")
                .OrderByDescending(r => r.SubmittedAt)
                .ToListAsync();
        }
    }
}

﻿using Capstone.Api.Models;

namespace Capstone.Api.Repositories.Interfaces
{
    public interface INotificationRepository
    {
        Task<IEnumerable<Notification>> GetByUserAsync(long userId);
        Task AddAsync(Notification entity);
        Task UpdateAsync(Notification entity);
        Task<Notification?> GetByIdAsync(long id);
    }
}

﻿using Capstone.Api.Models;

namespace Capstone.Api.Repositories.Interfaces
{
    public interface IMasterBenefitRepository
    {
        Task<IEnumerable<MasterBenefit>> GetAllAsync();
        Task<MasterBenefit?> GetByIdAsync(long id);
        Task AddAsync(MasterBenefit benefit);
        Task UpdateAsync(MasterBenefit benefit);
        Task<bool> ExistsAsync(long id);
    }
}

﻿using Capstone.Api.Models;

namespace Capstone.Api.Repositories.Interfaces
{
    public interface IQueryRepository
    {
        Task<IEnumerable<Query>> GetByUserAsync(long userId);
        Task<IEnumerable<Query>> GetAllAsync();
        Task<Query?> GetByIdAsync(long id);
        Task AddAsync(Query query);
        Task UpdateAsync(Query query);
    }
}

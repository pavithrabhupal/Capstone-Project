﻿using Capstone.Api.Models;

namespace Capstone.Api.Repositories.Interfaces
{
    public interface IUserBenefitRepository
    {
        Task<IEnumerable<UserBenefit>> GetByUserIdAsync(long userId);
        Task<UserBenefit?> GetByIdAsync(long id);
        Task AddAsync(UserBenefit userBenefit);
        Task<bool> HasActiveWellnessPlanAsync(long userId);
        Task<bool> UserBenefitExistsAsync(long userId, long masterBenefitId);
    }
}

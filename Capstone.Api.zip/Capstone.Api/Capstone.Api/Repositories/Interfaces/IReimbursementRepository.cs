﻿using Capstone.Api.Models;

namespace Capstone.Api.Repositories.Interfaces
{
    public interface IReimbursementRepository
    {
        Task AddAsync(Reimbursement r);
        Task UpdateAsync(Reimbursement r);
        Task<Reimbursement?> GetByIdAsync(long id);

        Task<bool> ExistsForMonthAsync(long userId, long userBenefitId, string monthYear);

        Task<IEnumerable<Reimbursement>> GetByUserAsync(long userId);  // FIXED
        Task<IEnumerable<Reimbursement>> GetAllAsync();               // FIXED

        Task<IEnumerable<Reimbursement>> GetPendingAsync();
    }
}

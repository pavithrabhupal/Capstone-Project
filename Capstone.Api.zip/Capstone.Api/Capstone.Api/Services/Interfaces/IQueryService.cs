﻿using Capstone.Api.DTOs.Queries;

namespace Capstone.Api.Services.Interfaces
{
    public interface IQueryService
    {
        Task<IEnumerable<QueryDto>> GetUserQueriesAsync(long userId);
        Task<IEnumerable<QueryDto>> GetAllAsync();
        Task<QueryDto> CreateAsync(long userId, CreateQueryDto dto);
        Task<bool> ReplyAsync(long queryId, ReplyQueryDto dto);
    }
}

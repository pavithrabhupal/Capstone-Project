﻿using Capstone.Api.DTOs.Reimbursements;
using Capstone.Api.Models;

namespace Capstone.Api.Services.Interfaces
{
    public interface IReimbursementService
    {
        Task<ReimbursementDto> SubmitAsync(long userId, SubmitReimbursementDto dto);
        Task<bool> DeleteReceiptAsync(long id, long userId);
        Task<ReimbursementDto?> GetByIdAsync(long id);
        Task<IEnumerable<ReimbursementDto>> GetByUserAsync(long userId);
        Task<IEnumerable<ReimbursementDto>> GetAllAsync();
        Task<bool> ApproveAsync(long id);
        Task<bool> RejectAsync(long id, string reason);
        Task<bool> AllowOverrideAsync(long id, DateTime expiry, string reason);
    }
}

﻿using Capstone.Api.DTOs.Notifications;

namespace Capstone.Api.Services.Interfaces
{
    public interface INotificationService
    {
        Task<IEnumerable<NotificationDto>> GetByUserAsync(long userId);
        Task AddAsync(long userId, string message, string type = "Info");
        Task<bool> MarkAsReadAsync(long id);
    }
}

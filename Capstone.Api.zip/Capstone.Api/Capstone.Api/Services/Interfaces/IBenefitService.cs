﻿using Capstone.Api.DTOs.Benefits;

namespace Capstone.Api.Services.Interfaces
{
    public interface IBenefitService
    {
        Task<IEnumerable<MasterBenefitDto>> GetAllAsync();
        Task<MasterBenefitDto?> GetByIdAsync(long id);
        Task<MasterBenefitDto> CreateAsync(CreateMasterBenefitDto dto);
        Task<MasterBenefitDto> UpdateAsync(long id, UpdateMasterBenefitDto dto);
        Task<bool> ToggleStatusAsync(long id); // Activate/Deactivate
    }
}

﻿using Capstone.Api.DTOs.Benefits;

namespace Capstone.Api.Services.Interfaces
{
    public interface IUserBenefitService
    {
        Task<IEnumerable<UserBenefitDto>> GetByUserAsync(long userId);
        Task<UserBenefitDto> EnrollAsync(long userId, AddUserBenefitDto dto);
        Task<UserBenefitDto?> GetByIdAsync(long id);
        Task<bool> ExtendPlanAsync(long userBenefitId, DateTime newExpiry, string reason);
        Task<IEnumerable<UserBenefitDto>> GetByUserIdAsync(long userId);

    }
}

﻿using Capstone.Api.DTOs.Auth;
using Capstone.Api.Helpers;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Services.Interfaces;
using Capstone.Api.Middleware.CustomExceptions;

using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Capstone.Api.Services.Implementations
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepo;
        private readonly IPasswordHasher _passwordHasher;
        private readonly IConfiguration _config;

        public AuthService(
            IUserRepository userRepo,
            IPasswordHasher passwordHasher,
            IConfiguration config)
        {
            _userRepo = userRepo;
            _passwordHasher = passwordHasher;
            _config = config;
        }

        // LOGIN
        public async Task<AuthResponseDto?> LoginAsync(LoginDto dto)
        {
            var user = await _userRepo.GetByEmailAsync(dto.Email);
            if (user == null)
                return null;

            bool isValid = _passwordHasher.Verify(dto.Password, user.PasswordHash);

            if (!isValid)
                return null;

            string token = GenerateJwtToken(user);

            return new AuthResponseDto
            {
                Token = token,
                Role = user.Role,
                UserId = user.UserId
            };
        }

        // REGISTER (Optional)
        public async Task<bool> RegisterAsync(RegisterDto dto)
        {
            if (await _userRepo.EmailExistsAsync(dto.Email))
                throw new ValidationException("Email already exists.");

            var user = new User
            {
                FullName = dto.FullName,
                Email = dto.Email,
                PasswordHash = _passwordHasher.Hash(dto.Password),
                Role = "Member",
                CreatedAt = DateTime.UtcNow
            };

            await _userRepo.AddAsync(user);
            return true;
        }

        // JWT GENERATION
        private string GenerateJwtToken(User user)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim("userId", user.UserId.ToString()),
                new Claim(ClaimTypes.Role, user.Role),
                new Claim(ClaimTypes.Email, user.Email)
            };

            var expiryHours = int.Parse(_config["Jwt:ExpiryHours"]);
            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(expiryHours),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}

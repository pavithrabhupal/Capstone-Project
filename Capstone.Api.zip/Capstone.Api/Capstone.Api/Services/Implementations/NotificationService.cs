﻿using Capstone.Api.DTOs.Notifications;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Services.Interfaces;

namespace Capstone.Api.Services.Implementations
{
    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _repo;

        public NotificationService(INotificationRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<NotificationDto>> GetByUserAsync(long userId)
        {
            var list = await _repo.GetByUserAsync(userId);

            return list.Select(n => new NotificationDto
            {
                NotificationId = n.NotificationId,
                UserId = n.UserId,
                Message = n.Message,
                Type = n.Type,
                IsRead = n.IsRead == 1,
                CreatedAt = n.CreatedAt
            });
        }

        public async Task AddAsync(long userId, string message, string type = "Info")
        {
            var n = new Notification
            {
                UserId = userId,
                Message = message,
                Type = type,
                IsRead = 0,
                CreatedAt = DateTime.UtcNow
            };

            await _repo.AddAsync(n);
        }

        public async Task<bool> MarkAsReadAsync(long id)
        {
            var n = await _repo.GetByIdAsync(id);
            if (n == null) return false;

            n.IsRead = 1;
            await _repo.UpdateAsync(n);

            return true;
        }
    }
}

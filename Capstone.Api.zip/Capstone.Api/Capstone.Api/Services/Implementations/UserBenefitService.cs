﻿using Capstone.Api.DTOs.Benefits;
using Capstone.Api.Middleware.CustomExceptions;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Services.Interfaces;

namespace Capstone.Api.Services.Implementations
{
    public class UserBenefitService : IUserBenefitService
    {
        private readonly IUserBenefitRepository _userBenefitRepo;
        private readonly IMasterBenefitRepository _masterBenefitRepo;
        private readonly IUserRepository _userRepo;

        public UserBenefitService(
            IUserBenefitRepository userBenefitRepo,
            IMasterBenefitRepository masterBenefitRepo,
            IUserRepository userRepo)
        {
            _userBenefitRepo = userBenefitRepo;
            _masterBenefitRepo = masterBenefitRepo;
            _userRepo = userRepo;
        }

        // ---------------------------------------------------------
        // GET ALL BENEFITS FOR USER
        // ---------------------------------------------------------
        public async Task<IEnumerable<UserBenefitDto>> GetByUserAsync(long userId)
        {
            var benefits = await _userBenefitRepo.GetByUserIdAsync(userId);

            return benefits.Select(ub => new UserBenefitDto
            {
                UserBenefitId = ub.UserBenefitId,
                UserId = ub.UserId,
                MasterBenefitId = ub.MasterBenefitId,
                BenefitName = ub.MasterBenefit.BenefitName,
                Category = ub.MasterBenefit.Category,
                SubCategory = ub.MasterBenefit.SubCategory,
                EffectiveDate = ub.EffectiveDate,
                ExpiryDate = ub.ExpiryDate,
                Status = ub.Status,
                Provider = ub.MasterBenefit.Provider,
                DefaultCopay = ub.MasterBenefit.DefaultCopay,
                MonthlyLimit = ub.MasterBenefit.MonthlyLimit
            });
        }

        // ---------------------------------------------------------
        // GET BENEFIT BY ID
        // ---------------------------------------------------------
        public async Task<UserBenefitDto?> GetByIdAsync(long id)
        {
            var ub = await _userBenefitRepo.GetByIdAsync(id);

            if (ub == null)
                throw new NotFoundException("User benefit not found.");

            return new UserBenefitDto
            {
                UserBenefitId = ub.UserBenefitId,
                UserId = ub.UserId,
                MasterBenefitId = ub.MasterBenefitId,
                BenefitName = ub.MasterBenefit.BenefitName,
                Category = ub.MasterBenefit.Category,
                SubCategory = ub.MasterBenefit.SubCategory,
                EffectiveDate = ub.EffectiveDate,
                ExpiryDate = ub.ExpiryDate,
                Status = ub.Status,
                Provider = ub.MasterBenefit.Provider,
                DefaultCopay = ub.MasterBenefit.DefaultCopay,
                MonthlyLimit = ub.MasterBenefit.MonthlyLimit
            };
        }

        // ---------------------------------------------------------
        // ENROLL IN BENEFIT (USER)
        // ---------------------------------------------------------
        public async Task<UserBenefitDto> EnrollAsync(long userId, AddUserBenefitDto dto)
        {
            var user = await _userRepo.GetByIdAsync(userId);
            if (user == null)
                throw new NotFoundException("User not found.");

            var benefit = await _masterBenefitRepo.GetByIdAsync(dto.MasterBenefitId);
            if (benefit == null)
                throw new NotFoundException("Benefit not found.");

            if (benefit.Status != "Active")
                throw new ValidationException("This benefit is not active.");

            // Prevent enrolling SAME plan while it is active
            bool alreadyActiveSame = (await _userBenefitRepo.GetByUserIdAsync(userId))
                .Any(ub => ub.MasterBenefitId == benefit.MasterBenefitId && ub.Status == "Active");

            if (alreadyActiveSame)
                throw new ValidationException("You already have this benefit active.");

            // ----------------------
            // WELLNESS LOGIC
            // ----------------------
            if (benefit.Category == "Wellness")
            {
                if (benefit.SubCategory == "Regular")
                {
                    // Prevent multiple regular wellness plans
                    bool hasActiveRegular = (await _userBenefitRepo.GetByUserIdAsync(userId))
                        .Any(ub =>
                            ub.MasterBenefit.Category == "Wellness" &&
                            ub.MasterBenefit.SubCategory == "Regular" &&
                            ub.Status == "Active"
                        );

                    if (hasActiveRegular)
                        throw new DuplicateEnrollmentException();
                }
                // Emergency --> ALWAYS allowed
            }

            // Create benefit
            var newBenefit = new UserBenefit
            {
                UserId = userId,
                MasterBenefitId = benefit.MasterBenefitId,
                EffectiveDate = dto.EffectiveDate,
                ExpiryDate = dto.ExpiryDate,
                Status = "Active"
            };

            await _userBenefitRepo.AddAsync(newBenefit);

            return new UserBenefitDto
            {
                UserBenefitId = newBenefit.UserBenefitId,
                UserId = newBenefit.UserId,
                MasterBenefitId = benefit.MasterBenefitId,
                BenefitName = benefit.BenefitName,
                Category = benefit.Category,
                SubCategory = benefit.SubCategory,
                EffectiveDate = newBenefit.EffectiveDate,
                ExpiryDate = newBenefit.ExpiryDate,
                Status = newBenefit.Status,
                Provider = benefit.Provider,
                DefaultCopay = benefit.DefaultCopay,
                MonthlyLimit = benefit.MonthlyLimit
            };
        }

        // ---------------------------------------------------------
        // ADMIN EXTENDS BENEFIT (Optional)
        // ---------------------------------------------------------
        public async Task<bool> ExtendPlanAsync(long userBenefitId, DateTime newExpiry, string reason)
        {
            var ub = await _userBenefitRepo.GetByIdAsync(userBenefitId);

            if (ub == null)
                throw new NotFoundException("User benefit not found.");

            if (newExpiry <= ub.ExpiryDate)
                throw new ValidationException("Extended expiry must be after current expiry.");

            ub.AdminExtended = 1;
            ub.ExtendedExpiryDate = newExpiry;
            ub.AdminExtensionReason = reason;

            await _userBenefitRepo.AddAsync(ub);
            return true;
        }

        public async Task<IEnumerable<UserBenefitDto>> GetByUserIdAsync(long userId)
        {
            var list = await _userBenefitRepo.GetByUserIdAsync(userId);

            return list.Select(ub => new UserBenefitDto
            {
                UserBenefitId = ub.UserBenefitId,
                UserId = ub.UserId,
                MasterBenefitId = ub.MasterBenefitId,
                BenefitName = ub.MasterBenefit.BenefitName,
                Category = ub.MasterBenefit.Category,
                SubCategory = ub.MasterBenefit.SubCategory,
                EffectiveDate = ub.EffectiveDate,
                ExpiryDate = ub.ExpiryDate,
                Status = ub.Status,
                AdminExtended = ub.AdminExtended
            });
        }

    }
}

﻿using Capstone.Api.DTOs.Queries;
using Capstone.Api.Middleware.CustomExceptions;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Services.Interfaces;

namespace Capstone.Api.Services.Implementations
{
    public class QueryService : IQueryService
    {
        private readonly IQueryRepository _repo;

        public QueryService(IQueryRepository repo)
        {
            _repo = repo;
        }

        public async Task<IEnumerable<QueryDto>> GetUserQueriesAsync(long userId)
        {
            var queries = await _repo.GetByUserAsync(userId);

            return queries.Select(q => new QueryDto
            {
                QueryId = q.QueryId,
                UserId = q.UserId,
                Subject = q.Subject,
                Message = q.Message,
                Reply = q.Reply,
                Status = q.Status,
                CreatedAt = q.CreatedAt,
                RepliedAt = q.RepliedAt
            });
        }

        public async Task<IEnumerable<QueryDto>> GetAllAsync()
        {
            var list = await _repo.GetAllAsync();

            return list.Select(q => new QueryDto
            {
                QueryId = q.QueryId,
                UserId = q.UserId,
                Subject = q.Subject,
                Message = q.Message,
                Reply = q.Reply,
                Status = q.Status,
                CreatedAt = q.CreatedAt,
                RepliedAt = q.RepliedAt
            });
        }

        public async Task<QueryDto> CreateAsync(long userId, CreateQueryDto dto)
        {
            var q = new Query
            {
                UserId = userId,
                Subject = dto.Subject,
                Message = dto.Message,
                Status = "Open",
                CreatedAt = DateTime.UtcNow
            };

            await _repo.AddAsync(q);

            return new QueryDto
            {
                QueryId = q.QueryId,
                UserId = q.UserId,
                Subject = q.Subject,
                Message = q.Message,
                Status = q.Status,
                CreatedAt = q.CreatedAt
            };
        }

        public async Task<bool> ReplyAsync(long queryId, ReplyQueryDto dto)
        {
            var q = await _repo.GetByIdAsync(queryId);

            if (q == null)
                throw new NotFoundException("Query not found.");

            q.Reply = dto.Reply;
            q.Status = "Replied";
            q.RepliedAt = DateTime.UtcNow;

            await _repo.UpdateAsync(q);

            return true;
        }
    }
}

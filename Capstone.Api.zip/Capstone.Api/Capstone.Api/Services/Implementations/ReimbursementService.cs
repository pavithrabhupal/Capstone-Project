﻿using Capstone.Api.DTOs.Reimbursements;
using Capstone.Api.Middleware.CustomExceptions;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Services.Interfaces;
using Microsoft.AspNetCore.Hosting;

namespace Capstone.Api.Services.Implementations
{
    public class ReimbursementService : IReimbursementService
    {
        private readonly IReimbursementRepository _repo;
        private readonly IUserBenefitRepository _userBenefitRepo;
        private readonly IUserRepository _userRepo;
        private readonly INotificationRepository _notificationRepo;
        private readonly IWebHostEnvironment _env;

        public ReimbursementService(
            IReimbursementRepository repo,
            IUserBenefitRepository userBenefitRepo,
            IUserRepository userRepo,
            INotificationRepository notificationRepo,
            IWebHostEnvironment env)
        {
            _repo = repo;
            _userBenefitRepo = userBenefitRepo;
            _userRepo = userRepo;
            _notificationRepo = notificationRepo;
            _env = env;
        }

        // Save Receipt File
        private string SaveReceipt(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return string.Empty;

            var folder = Path.Combine(_env.WebRootPath, "Uploads", "Receipts");

            if (!Directory.Exists(folder))
                Directory.CreateDirectory(folder);

            var fileName = $"{Guid.NewGuid()}_{file.FileName}";
            var filePath = Path.Combine(folder, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                file.CopyTo(stream);
            }

            return fileName;
        }

        // Submit Reimbursement
        public async Task<ReimbursementDto> SubmitAsync(long userId, SubmitReimbursementDto dto)
        {
            var user = await _userRepo.GetByIdAsync(userId)
                ?? throw new NotFoundException("User not found.");

            var ub = await _userBenefitRepo.GetByIdAsync(dto.UserBenefitId)
                ?? throw new NotFoundException("Benefit not found.");

            if (ub.UserId != userId)
                throw new UnauthorizedOperationException();

            if (ub.MasterBenefit.Category != "Wellness")
                throw new WellnessPlanNotActiveException();

            var today = DateTime.UtcNow.Date;
            bool active = today >= ub.EffectiveDate && today <= ub.ExpiryDate;
            bool extended = ub.AdminExtended == 1;

            if (!active && !extended)
                throw new WellnessPlanNotActiveException();

            string monthKey = dto.DateOfActivity.ToString("yyyy-MM");

            if (await _repo.ExistsForMonthAsync(userId, ub.UserBenefitId, monthKey))
                throw new AlreadySubmittedException();

            if (dto.Amount > ub.MasterBenefit.MonthlyLimit)
                throw new LimitExceededException();

            var fileName = SaveReceipt(dto.ReceiptFile);

            var r = new Reimbursement
            {
                UserId = userId,
                UserBenefitId = ub.UserBenefitId,
                Amount = dto.Amount,
                DateOfActivity = dto.DateOfActivity,
                MonthYear = monthKey,
                ReceiptPath = fileName,
                Status = "Submitted",
                SubmittedAt = DateTime.UtcNow,
                IsOverrideEnabled = 0
            };

            await _repo.AddAsync(r);

            await _notificationRepo.AddAsync(new Notification
            {
                UserId = userId,
                Message = $"Reimbursement submitted for {monthKey}.",
                Type = "Success",
                CreatedAt = DateTime.UtcNow,
                IsRead = 0
            });

            return new ReimbursementDto
            {
                ReimbursementId = r.ReimbursementId,
                UserBenefitId = r.UserBenefitId,
                Amount = r.Amount,
                Status = r.Status,
                MonthYear = r.MonthYear,
                ReceiptPath = r.ReceiptPath
            };
        }

        // Delete Receipt (user fix wrong upload)
        public async Task<bool> DeleteReceiptAsync(long id, long userId)
        {
            var r = await _repo.GetByIdAsync(id)
                ?? throw new NotFoundException("Reimbursement not found.");

            if (r.UserId != userId)
                throw new UnauthorizedOperationException();

            if (r.Status == "Approved" || r.Status == "Rejected")
                throw new ValidationException("Cannot modify after approval.");

            if (!string.IsNullOrEmpty(r.ReceiptPath))
            {
                var filePath = Path.Combine(_env.ContentRootPath, "Uploads", "Receipts", r.ReceiptPath);
                if (File.Exists(filePath))
                    File.Delete(filePath);
            }

            r.ReceiptPath = null;
            r.Status = "Draft";

            await _repo.UpdateAsync(r);
            return true;
        }

        // Get by ID
        public async Task<ReimbursementDto?> GetByIdAsync(long id)
        {
            var r = await _repo.GetByIdAsync(id);
            if (r == null) return null;

            return new ReimbursementDto
            {
                ReimbursementId = r.ReimbursementId,
                UserBenefitId = r.UserBenefitId,
                MonthYear = r.MonthYear,
                Amount = r.Amount,
                Status = r.Status,
                ReceiptPath = r.ReceiptPath
            };
        }

        // Get reimbursements for user
        public async Task<IEnumerable<ReimbursementDto>> GetByUserAsync(long userId)
        {
            var list = await _repo.GetByUserAsync(userId);

            return list.Select(r => new ReimbursementDto
            {
                ReimbursementId = r.ReimbursementId,
                UserBenefitId = r.UserBenefitId,
                Amount = r.Amount,
                Status = r.Status,
                MonthYear = r.MonthYear,
                ReceiptPath = r.ReceiptPath
            });
        }

        // Get all reimbursements
        public async Task<IEnumerable<ReimbursementDto>> GetAllAsync()
        {
            var list = await _repo.GetAllAsync();

            return list.Select(r => new ReimbursementDto
            {
                ReimbursementId = r.ReimbursementId,
                UserBenefitId = r.UserBenefitId,
                Amount = r.Amount,
                Status = r.Status,
                MonthYear = r.MonthYear,
                ReceiptPath = r.ReceiptPath
            });
        }

        // Approve
        public async Task<bool> ApproveAsync(long id)
        {
            var r = await _repo.GetByIdAsync(id)
                ?? throw new NotFoundException("Not found.");

            r.Status = "Approved";
            r.ApprovedAt = DateTime.UtcNow;

            await _repo.UpdateAsync(r);

            await _notificationRepo.AddAsync(new Notification
            {
                UserId = r.UserId,
                Message = $"Reimbursement approved for {r.MonthYear}",
                Type = "Success",
                CreatedAt = DateTime.UtcNow
            });

            return true;
        }

        // Reject
        public async Task<bool> RejectAsync(long id, string reason)
        {
            var r = await _repo.GetByIdAsync(id)
                ?? throw new NotFoundException("Not found.");

            r.Status = "Rejected";
            r.RejectReason = reason;

            await _repo.UpdateAsync(r);

            await _notificationRepo.AddAsync(new Notification
            {
                UserId = r.UserId,
                Message = $"Reimbursement rejected: {reason}",
                Type = "Warning",
                CreatedAt = DateTime.UtcNow
            });

            return true;
        }

        // Allow override
        public async Task<bool> AllowOverrideAsync(long id, DateTime expiry, string reason)
        {
            var r = await _repo.GetByIdAsync(id)
                ?? throw new NotFoundException("Not found.");

            r.IsOverrideEnabled = 1;
            r.OverrideExpiryDate = expiry;
            r.AdminOverrideReason = reason;
            r.Status = "OverrideAllowed";

            await _repo.UpdateAsync(r);

            await _notificationRepo.AddAsync(new Notification
            {
                UserId = r.UserId,
                Message = $"Override allowed: {reason}",
                Type = "Info",
                CreatedAt = DateTime.UtcNow
            });

            return true;
        }
    }
}

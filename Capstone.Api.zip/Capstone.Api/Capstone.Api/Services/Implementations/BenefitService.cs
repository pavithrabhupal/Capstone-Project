﻿using Capstone.Api.DTOs.Benefits;
using Capstone.Api.Middleware.CustomExceptions;
using Capstone.Api.Models;
using Capstone.Api.Repositories.Interfaces;
using Capstone.Api.Services.Interfaces;

namespace Capstone.Api.Services.Implementations
{
    public class BenefitService : IBenefitService
    {
        private readonly IMasterBenefitRepository _repo;

        public BenefitService(IMasterBenefitRepository repo)
        {
            _repo = repo;
        }

        // ---------------------------------------------------------
        // GET ALL BENEFITS
        // ---------------------------------------------------------
        public async Task<IEnumerable<MasterBenefitDto>> GetAllAsync()
        {
            var benefits = await _repo.GetAllAsync();

            return benefits.Select(b => new MasterBenefitDto
            {
                MasterBenefitId = b.MasterBenefitId,
                BenefitName = b.BenefitName,
                Category = b.Category,
                SubCategory = b.SubCategory,
                Description = b.Description,
                Provider = b.Provider,
                DefaultCopay = b.DefaultCopay,
                MonthlyLimit = b.MonthlyLimit,
                Status = b.Status
            });
        }

        // ---------------------------------------------------------
        // GET SINGLE BENEFIT BY ID
        // ---------------------------------------------------------
        public async Task<MasterBenefitDto?> GetByIdAsync(long id)
        {
            var b = await _repo.GetByIdAsync(id);

            if (b == null)
                throw new NotFoundException("Benefit not found.");

            return new MasterBenefitDto
            {
                MasterBenefitId = b.MasterBenefitId,
                BenefitName = b.BenefitName,
                Category = b.Category,
                SubCategory = b.SubCategory,
                Description = b.Description,
                Provider = b.Provider,
                DefaultCopay = b.DefaultCopay,
                MonthlyLimit = b.MonthlyLimit,
                Status = b.Status
            };
        }

        // ---------------------------------------------------------
        // CREATE BENEFIT
        // ---------------------------------------------------------
        public async Task<MasterBenefitDto> CreateAsync(CreateMasterBenefitDto dto)
        {
            var benefit = new MasterBenefit
            {
                BenefitName = dto.BenefitName,
                Category = dto.Category,
                SubCategory = dto.SubCategory,
                Description = dto.Description,
                Provider = dto.Provider,
                DefaultCopay = dto.DefaultCopay,
                MonthlyLimit = dto.MonthlyLimit,
                Status = "Active"
            };

            await _repo.AddAsync(benefit);

            return new MasterBenefitDto
            {
                MasterBenefitId = benefit.MasterBenefitId,
                BenefitName = benefit.BenefitName,
                Category = benefit.Category,
                SubCategory = benefit.SubCategory,
                Description = benefit.Description,
                Provider = benefit.Provider,
                DefaultCopay = benefit.DefaultCopay,
                MonthlyLimit = benefit.MonthlyLimit,
                Status = benefit.Status
            };
        }

        // ---------------------------------------------------------
        // UPDATE BENEFIT
        // ---------------------------------------------------------
        public async Task<MasterBenefitDto> UpdateAsync(long id, UpdateMasterBenefitDto dto)
        {
            var b = await _repo.GetByIdAsync(id);

            if (b == null)
                throw new NotFoundException("Benefit not found.");

            b.BenefitName = dto.BenefitName;
            b.SubCategory = dto.SubCategory;
            b.Description = dto.Description;
            b.Provider = dto.Provider;
            b.DefaultCopay = dto.DefaultCopay;
            b.MonthlyLimit = dto.MonthlyLimit;

            await _repo.UpdateAsync(b);

            return new MasterBenefitDto
            {
                MasterBenefitId = b.MasterBenefitId,
                BenefitName = b.BenefitName,
                Category = b.Category,
                SubCategory = b.SubCategory,
                Description = b.Description,
                Provider = b.Provider,
                DefaultCopay = b.DefaultCopay,
                MonthlyLimit = b.MonthlyLimit,
                Status = b.Status
            };
        }

        // ---------------------------------------------------------
        // TOGGLE ACTIVE/INACTIVE
        // ---------------------------------------------------------
        public async Task<bool> ToggleStatusAsync(long id)
        {
            var b = await _repo.GetByIdAsync(id);

            if (b == null)
                throw new NotFoundException("Benefit not found.");

            b.Status = b.Status == "Active" ? "Inactive" : "Active";

            await _repo.UpdateAsync(b);
            return true;
        }
    }
}

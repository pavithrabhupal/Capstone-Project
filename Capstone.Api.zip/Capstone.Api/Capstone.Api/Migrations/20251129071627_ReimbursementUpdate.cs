﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Capstone.Api.Migrations
{
    /// <inheritdoc />
    public partial class ReimbursementUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "ReceiptPath",
                table: "Reimbursements",
                type: "NVARCHAR2(2000)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "NVARCHAR2(2000)");

            migrationBuilder.AddColumn<string>(
                name: "RejectReason",
                table: "Reimbursements",
                type: "NVARCHAR2(2000)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RejectReason",
                table: "Reimbursements");

            migrationBuilder.AlterColumn<string>(
                name: "ReceiptPath",
                table: "Reimbursements",
                type: "NVARCHAR2(2000)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "NVARCHAR2(2000)",
                oldNullable: true);
        }
    }
}

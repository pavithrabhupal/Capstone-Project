﻿using Capstone.Api.DTOs.Benefits;
using Capstone.Api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Capstone.Api.Controllers
{
    [ApiController]
    [Route("api/user-benefits")]
    [Authorize]
    public class UserBenefitController : ControllerBase
    {
        private readonly IUserBenefitService _service;

        public UserBenefitController(IUserBenefitService service)
        {
            _service = service;
        }

        private long GetUserId() =>
            long.Parse(User.FindFirstValue("userId"));

        [HttpGet]
        public async Task<IActionResult> GetMyBenefits() =>
            Ok(await _service.GetByUserAsync(GetUserId()));

        [HttpPost]
        public async Task<IActionResult> Enroll(AddUserBenefitDto dto)
        {
            var result = await _service.EnrollAsync(GetUserId(), dto);
            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id}/extend")]
        public async Task<IActionResult> Extend(long id, DateTime newExpiry, string reason)
        {
            await _service.ExtendPlanAsync(id, newExpiry, reason);
            return Ok(new { message = "Updated" });
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("users/{userId}")]
        public async Task<IActionResult> GetBenefitsForUser(long userId)
        {
            var list = await _service.GetByUserIdAsync(userId);
            return Ok(list);
        }

    }
}

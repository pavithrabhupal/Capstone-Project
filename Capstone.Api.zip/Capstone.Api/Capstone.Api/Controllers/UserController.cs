﻿using Capstone.Api.Repositories.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Capstone.Api.Controllers
{
    [ApiController]
    [Route("api/users")]
    [Authorize(Roles = "Admin")]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _repo;

        public UserController(IUserRepository repo)
        {
            _repo = repo;
        }

        // Get all users
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var users = await _repo.GetAllAsync();
            return Ok(users.Select(u => new
            {
                u.UserId,
                u.FullName,
                u.Email,
                u.Role,
                u.CreatedAt
            }));
        }

        // Get user by ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(long id)
        {
            var user = await _repo.GetByIdAsync(id);
            if (user == null)
                return NotFound(new { message = "User not found" });

            return Ok(new
            {
                user.UserId,
                user.FullName,
                user.Email,
                user.Role,
                user.CreatedAt
            });
        }
    }
}

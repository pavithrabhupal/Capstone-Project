﻿using Capstone.Api.DTOs.Benefits;
using Capstone.Api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Capstone.Api.Controllers
{
    [ApiController]
    [Route("api/benefits")]
    [Authorize(Roles = "Admin")]
    public class BenefitController : ControllerBase
    {
        private readonly IBenefitService _service;

        public BenefitController(IBenefitService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll() =>
            Ok(await _service.GetAllAsync());

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(long id) =>
            Ok(await _service.GetByIdAsync(id));

        [HttpPost]
        public async Task<IActionResult> Create(CreateMasterBenefitDto dto)
        {
            var result = await _service.CreateAsync(dto);
            return Ok(result);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(long id, UpdateMasterBenefitDto dto)
        {
            var result = await _service.UpdateAsync(id, dto);
            return Ok(result);
        }

        [HttpPut("{id}/toggle")]
        public async Task<IActionResult> Toggle(long id)
        {
            await _service.ToggleStatusAsync(id);
            return Ok(new { message = "Updated" });
        }
    }
}

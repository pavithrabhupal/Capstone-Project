﻿using Capstone.Api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Capstone.Api.Controllers
{
    [ApiController]
    [Route("api/notifications")]
    [Authorize]
    public class NotificationController : ControllerBase
    {
        private readonly INotificationService _service;

        public NotificationController(INotificationService service)
        {
            _service = service;
        }

        private long GetUserId() =>
            long.Parse(User.FindFirstValue("userId"));

        [HttpGet]
        public async Task<IActionResult> GetMyNotifications() =>
            Ok(await _service.GetByUserAsync(GetUserId()));

        [HttpPut("{id}/read")]
        public async Task<IActionResult> MarkRead(long id)
        {
            await _service.MarkAsReadAsync(id);
            return Ok(new { message = "Read" });
        }
    }
}

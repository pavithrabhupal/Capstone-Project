﻿using Capstone.Api.DTOs.Queries;
using Capstone.Api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Capstone.Api.Controllers
{
    [ApiController]
    [Route("api/queries")]
    [Authorize]
    public class QueryController : ControllerBase
    {
        private readonly IQueryService _service;

        public QueryController(IQueryService service)
        {
            _service = service;
        }

        private long GetUserId() =>
            long.Parse(User.FindFirstValue("userId"));

        [HttpGet("my")]
        public async Task<IActionResult> MyQueries() =>
            Ok(await _service.GetUserQueriesAsync(GetUserId()));

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAll() =>
            Ok(await _service.GetAllAsync());

        [HttpPost]
        public async Task<IActionResult> Create(CreateQueryDto dto)
        {
            var result = await _service.CreateAsync(GetUserId(), dto);
            return Ok(result);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id}/reply")]
        public async Task<IActionResult> Reply(long id, ReplyQueryDto dto)
        {
            await _service.ReplyAsync(id, dto);
            return Ok(new { message = "Replied" });
        }
    }
}

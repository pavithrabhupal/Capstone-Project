﻿using Capstone.Api.DTOs.Reimbursements;
using Capstone.Api.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Capstone.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReimbursementController : ControllerBase
    {
        private readonly IReimbursementService _service;

        public ReimbursementController(IReimbursementService service)
        {
            _service = service;
        }

        // USER submits reimbursement
        [Authorize]
        [HttpPost("submit")]
        public async Task<IActionResult> Submit([FromForm] SubmitReimbursementDto dto)
        {
            var userId = long.Parse(User.FindFirst("userId")!.Value);
            var result = await _service.SubmitAsync(userId, dto);
            return Ok(result);
        }

        // USER delete wrong receipt
        [Authorize]
        [HttpDelete("{id}/receipt")]
        public async Task<IActionResult> DeleteReceipt(long id)
        {
            var userId = long.Parse(User.FindFirst("userId")!.Value);
            await _service.DeleteReceiptAsync(id, userId);
            return Ok(new { message = "Receipt deleted. You can upload a new one." });
        }

        // USER view receipt URL
        [Authorize]
        [HttpGet("{id}/receipt")]
        public async Task<IActionResult> GetReceipt(long id)
        {
            var r = await _service.GetByIdAsync(id);
            if (r == null || string.IsNullOrEmpty(r.ReceiptPath))
                return NotFound("Receipt not available.");

            var url = $"{Request.Scheme}://{Request.Host}/uploads/Receipts/{r.ReceiptPath}";
            return Ok(new { receiptUrl = url });
        }

        // USER: Get own reimbursements
        [Authorize]
        [HttpGet("my")]
        public async Task<IActionResult> GetMyReimbursements()
        {
            var userId = long.Parse(User.FindFirst("userId")!.Value);
            return Ok(await _service.GetByUserAsync(userId));
        }

        // ADMIN: Get all reimbursements
        [Authorize(Roles = "Admin")]
        [HttpGet("all")]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _service.GetAllAsync());
        }

        // ADMIN: Approve
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}/approve")]
        public async Task<IActionResult> Approve(long id)
        {
            await _service.ApproveAsync(id);
            return Ok(new { message = "Reimbursement approved" });
        }

        // ADMIN: Reject
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}/reject")]
        public async Task<IActionResult> Reject(long id, [FromBody] RejectDto dto)
        {
            await _service.RejectAsync(id, dto.Reason);
            return Ok(new { message = "Reimbursement rejected" });
        }

        // ADMIN: Allow override
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}/override")]
        public async Task<IActionResult> Override(long id, [FromBody] OverrideDto dto)
        {
            await _service.AllowOverrideAsync(id, dto.ExpiryDate, dto.Reason);
            return Ok(new { message = "Override allowed" });
        }
    }
}

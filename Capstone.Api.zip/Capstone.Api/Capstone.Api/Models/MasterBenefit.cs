﻿namespace Capstone.Api.Models
{
    public class MasterBenefit
    {
        public long MasterBenefitId { get; set; }
        public string BenefitName { get; set; } = null!;
        public string Category { get; set; } = null!; // Health / Wellness

        // Health plan fields
        public string? Provider { get; set; }
        public decimal? DefaultCopay { get; set; }

        // Wellness plan field
        public decimal? MonthlyLimit { get; set; }

        public string? Description { get; set; }
        public string Status { get; set; } = "Active"; // Active / Inactive
        public string SubCategory { get; set; } = "Regular"; //Regualr, Emergency

        // Navigation
        public ICollection<UserBenefit> UserBenefits { get; set; } = new List<UserBenefit>();
    }
}

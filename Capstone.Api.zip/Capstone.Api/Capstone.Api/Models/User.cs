﻿using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Capstone.Api.Models
{
    public class User
    {
        public long UserId { get; set; }
        public string FullName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;
        public string Role { get; set; } = "Member"; // Admin / Member
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation
        public ICollection<UserBenefit> UserBenefits { get; set; } = new List<UserBenefit>();
        public ICollection<Reimbursement> Reimbursements { get; set; } = new List<Reimbursement>();
        public ICollection<Query> Queries { get; set; } = new List<Query>();
        public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
    }
}

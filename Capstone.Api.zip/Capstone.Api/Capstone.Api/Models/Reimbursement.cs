﻿namespace Capstone.Api.Models
{
    public class Reimbursement
    {
        public long ReimbursementId { get; set; }
        public long UserId { get; set; }
        public long UserBenefitId { get; set; }

        public decimal Amount { get; set; }
        public string MonthYear { get; set; } = "";
        public DateTime DateOfActivity { get; set; }

        public string? ReceiptPath { get; set; }
        public string Status { get; set; } = "Submitted";

        public DateTime SubmittedAt { get; set; } = DateTime.UtcNow;
        public DateTime? ApprovedAt { get; set; }
        public string? RejectReason { get; set; }

        // Override support
        public int IsOverrideEnabled { get; set; } = 0;
        public DateTime? OverrideExpiryDate { get; set; }
        public string? AdminOverrideReason { get; set; }

        // Navigation
        public User? User { get; set; }
        public UserBenefit? UserBenefit { get; set; }
    }
}

﻿namespace Capstone.Api.Models
{
    public class Query
    {
        public long QueryId { get; set; }

        public long UserId { get; set; }
        public User User { get; set; } = null!;

        public string Subject { get; set; } = null!;
        public string Message { get; set; } = null!;

        public string? Reply { get; set; }
        public string Status { get; set; } = "Open"; // Open / Replied / Closed

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? RepliedAt { get; set; }
    }
}

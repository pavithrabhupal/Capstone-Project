﻿namespace Capstone.Api.Models
{
    public class UserBenefit
    {
        public long UserBenefitId { get; set; }

        public long UserId { get; set; }
        public User User { get; set; } = null!;

        public long MasterBenefitId { get; set; }
        public MasterBenefit MasterBenefit { get; set; } = null!;

        public DateTime EffectiveDate { get; set; }
        public DateTime ExpiryDate { get; set; }

        public string Status { get; set; } = "Active"; // Active / Expired / Cancelled

        // Admin override extension
        public int AdminExtended { get; set; } = 0;
        public string? AdminExtensionReason { get; set; }
        public DateTime? ExtendedExpiryDate { get; set; }

        // Navigation
        public ICollection<Reimbursement> Reimbursements { get; set; } = new List<Reimbursement>();
    }
}

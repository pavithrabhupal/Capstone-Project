﻿namespace Capstone.Api.Models
{
    public class Notification
    {
        public long NotificationId { get; set; }

        public long UserId { get; set; }
        public User User { get; set; } = null!;

        public string Message { get; set; } = null!;
        public string Type { get; set; } = "Info"; // Info / Warning / Success / Alert

        public int IsRead { get; set; } 
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
